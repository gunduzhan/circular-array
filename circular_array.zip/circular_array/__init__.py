bl_info = {
    "name": "Circular Array",
    "author": "Gunduzhan Gunduz",
    "version": (1, 0),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > Circular Array",
    "description": "Creates circular arrays with advanced features",
    "warning": "",
    "wiki_url": "https://github.com/gunduzhan/circular_array",
    "tracker_url": "https://github.com/gunduzhan/circular_array/issues",
    "support": "COMMUNITY",
    "category": "Add Mesh"
}

if "bpy" in locals():
    import importlib
    importlib.reload(circular_array)
else:
    from . import circular_array

import bpy

def register():
    circular_array.register()

def unregister():
    circular_array.unregister()

if __name__ == "__main__":
    register()